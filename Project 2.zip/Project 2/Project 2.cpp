// Project 2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
Osaretin Odigie

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

int main() {
    // To declare the variables for input

    double initialInvestmentAmount;
    double monthlyDeposit;
    double annualInterestRate;
    int numberOfYears;
    // To declare constants

    const int monthsInYear = 12;

    // Prompts the user for input values

    cout << "Welcome to the Airgead Banking Investment Calculator!" << endl;
    cout << "Enter initial investment amount (in dollars): ";
    cin >> initialInvestmentAmount;
    cout << "Enter monthly deposit amount (in dollars): ";
    cin >> monthlyDeposit;
    cout << "Enter annual interest rate (as a percentage): ";
    cin >> annualInterestRate;
    cout << "Enter number of years to invest: ";
    cin >> numberOfYears;

    // Opens the file for the output

    ofstream outputFile("InvestmentSummary.txt");
    if (!outputFile) {
        cerr << "Error opening output file." << endl;
        return 1;
    }

    // Prints to the output file
    outputFile << fixed << setprecision(2);
    outputFile << left << setw(6) << "Year"
               << right << setw(18) << "Opening Balance"
               << setw(18) << "Deposited Amount"
               << setw(18) << "Interest Earned"
               << setw(18) << "Closing Balance" << endl;

    // Prepares variables for calculations
    double currentBalance = initialInvestmentAmount;

    // Loops through each year

    for (int year = 1; year <= numberOfYears; year++) {
        double openingBalance = currentBalance;
        double totalDeposited = 0.0;
        double interestEarned = 0.0;

        // Loops through each month of this year

        for (int month = 1; month <= monthsInYear; month++) {
            // To add monthly deposit at the beginning of month
            currentBalance += monthlyDeposit;
            totalDeposited += monthlyDeposit;

            // For calculating the monthly interest

            double monthlyInterestRate = (annualInterestRate / 100.0) / monthsInYear;
            double monthlyInterest = currentBalance * monthlyInterestRate;
            interestEarned += monthlyInterest;

            // To add interest to the balance
            currentBalance += monthlyInterest;
        }

        double closingBalance = currentBalance;

        // this outputs the year's summary to the file
        outputFile << left << setw(6) << year
                   << right << setw(18) << openingBalance
                   << setw(18) << totalDeposited
                   << setw(18) << interestEarned
                   << setw(18) << closingBalance << endl;
    }

    outputFile.close();
    cout << "Investment summary written to InvestmentSummary.txt" << endl;

    return 0;
}


